let texto = "Observe que essa mensgaem vem do modulo";
module.exports = texto;

