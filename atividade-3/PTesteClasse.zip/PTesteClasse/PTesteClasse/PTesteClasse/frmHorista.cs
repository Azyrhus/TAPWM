﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteClasse
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }
        private void btnInstancian1_Click(object sender, EventArgs e)
        {
            Horista objhorista = new Horista();
            objhorista.NomeEmpregado = txtNome.Text;
            objhorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objhorista.SalarioHora = Convert.ToDouble(txtSalario.Text);
            objhorista.NumeroHora = Convert.ToDouble(txtNumero.Text);
            objhorista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            objhorista.DiasFalta = Convert.ToInt32(txtFaltas.Text);
            MessageBox.Show("Nome: " + objhorista.NomeEmpregado +
                "\n" + "Matricula: " + objhorista.Matricula + "\n" +
                "Tempo Trabalho: " + objhorista.TempoTrabalho() +
                "\n" + "Salário: " +
                objhorista.SalarioBruto().ToString("N2"));
        }
    }
}
