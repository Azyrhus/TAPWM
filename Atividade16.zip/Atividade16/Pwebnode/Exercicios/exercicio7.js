let http = require('http');
let server = http.createServer(function(req,res){
let url =req.url;
if(url=='/historia'){
    res.end("<html><head><style>body{font-family:sans-serif;background:#f0f0f0;text-align:center;padding-top:50px;}h1{color:#2c3e50;}div{background:white;padding:30px;margin:auto;width:60%;border-radius:10px;box-shadow:0 0 10px rgba(0,0,0,0.1);}</style></head><body><div><h1>Site da FATEC Sorocaba na aba de <em>História</em></h1></div></body></html>");
}
else if(url=='/curso'){
    res.end("<html><head><style>body{font-family:sans-serif;background:#f0f0f0;text-align:center;padding-top:50px;}h1{color:#16a085;}div{background:white;padding:30px;margin:auto;width:60%;border-radius:10px;box-shadow:0 0 10px rgba(0,0,0,0.1);}</style></head><body><div><h1>Site da FATEC Sorocaba na aba de <em>Curso</em></h1></div></body></html>");
}

else if(url=='/professor'){
    res.end("<html><head><style>body{font-family:sans-serif;background:#f0f0f0;text-align:center;padding-top:50px;}h1{color:#8e44ad;}div{background:white;padding:30px;margin:auto;width:60%;border-radius:10px;box-shadow:0 0 10px rgba(0,0,0,0.1);}</style></head><body><div><h1>Site da FATEC Sorocaba na aba de <em>Professor</em></h1></div></body></html>");
}

else{
    res.end("<html><head><style>body{font-family:sans-serif;background:#f0f0f0;text-align:center;padding-top:50px;}h1{color:#2980b9;}div{background:white;padding:30px;margin:auto;width:60%;border-radius:10px;box-shadow:0 0 10px rgba(0,0,0,0.1);}</style></head><body><div><h1>Bem-vindo ao site da <strong>FATEC Sorocaba</strong></h1></div></body></html>");
}

});
server.listen(3000)